"""Current original public review; frozen Guard/reader/Job/locks, no old main."""
import argparse
import hashlib
import json
from pathlib import Path
import types
HOME=Path(__file__).absolute().parent

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--config',required=True);parser.add_argument('--config-sha256',required=True)
    args=parser.parse_args()
    manifest_raw=(HOME/'manifest.json').read_bytes();manifest=json.loads(manifest_raw)
    if hashlib.sha256(manifest_raw).hexdigest()!=args.manifest_sha256:raise RuntimeError('reviewed new controls')
    common_raw=(HOME/'control_common.py').read_bytes()
    if hashlib.sha256(common_raw).hexdigest()!=manifest['files']['control_common.py']['sha256']:raise RuntimeError('reviewed small adapter')
    M=types.ModuleType('_Root_current_review_controls');M.__file__=str(HOME/'control_common.py');exec(compile(common_raw,M.__file__,'exec'),M.__dict__)
    H,R,C,P,own=M.load(args.manifest_sha256)
    config_path=H.plain(M.TASK/args.config)
    H.require(config_path==H.plain(M.SEAL/'config.json') and H.hash_file(config_path)==args.config_sha256,'this actual new Root config')
    config=C.json_value(H.read(config_path))
    H.require(all(config[name] is True for name in ('Root_public_review_prepare_admitted','Root_request_actual_ready_staged',
        'Root_fresh_source_closed','Root_normal_token','original_nx_two_lock_scope_admitted',
        'authenticated_capture_exact_reads_admitted','official_CLI_public_data_only_scope_admitted'))
        and config['control_manifest_sha256']==args.manifest_sha256 and config['request_ref']==M.REQUEST
        and config['source_commit']==C.HEAD and config['source_overlay_sha256']==C.OVERLAY_SHA
        and config['model_calls_allowed']==0,'actual current finite original public/native role admission')
    out=H.plain(M.OUT,missing=True);H.require(not out.exists(),'exclusive current review attempt; no retry')
    M.close_sources(H,R,C,P,config)
    H.require(H.snapshot_tree(H.TARGET)==config['target_before'] and H.hash_file(H.TARGET/M.REQUEST)==config['request_sha256']
        and not (H.TARGET/H.REVIEW_HOME).exists(),'fresh exact staged Request02/whole target and original review-home absence')
    out.mkdir(exist_ok=False);(out/'tmp').mkdir(exist_ok=False);H.write_new(out/'offline-codex-home/models_cache.json',H.MODEL_CATALOG)
    environment=M.safe_environment(H,out);H.os.environ.clear();H.os.environ.update(environment)
    guard=H.Guard(config,out);M.guard_inputs(H,R,C,guard,config,own,config_path,args.config_sha256)
    guard.files.update({H.key(H.PYTHON):H.PYTHON_SHA,H.key(H.GIT):H.GIT_SHA,
        H.key(out/'offline-codex-home/models_cache.json'):H.digest(H.MODEL_CATALOG)})
    # Only local orchestration aliases. Actual Guard functions retain H globals,
    # their frozen code/filename, original product bindings and check order.
    require,hash_file,write_new,raw_json=H.require,H.hash_file,H.write_new,H.raw_json
    snapshot_tree,target_close,Loader=H.snapshot_tree,H.target_close,H.Loader
    SOURCE,TARGET,OPERATION,REQUEST=H.SOURCE,H.TARGET,H.OPERATION,H.REQUEST
    REVIEW_FILES,REVIEW_HOME=H.REVIEW_FILES,H.REVIEW_HOME
    io,contextlib,importlib,traceback=H.io,H.contextlib,H.importlib,H.traceback
    def source_close(value):M.close_sources(H,R,C,P,value)
    stdout,stderr=io.StringIO(),io.StringIO()
    outcome={'passed':False,'operation_id':OPERATION,'stage':'review-prepare','model_calls':0,
        'formal_acceptance':False,'automatic_retry':False,'paid_or_unknown':80,'guard_occupancy':178,'campaign_limit':290,'released':0,
        'offline_catalog_is_current_model_or_high_evidence':False,'source_commit':C.HEAD,'source_overlay_sha256':C.OVERLAY_SHA,
        'config_ref':config_path.relative_to(M.TASK).as_posix(),'config_sha256':args.config_sha256,
        'control_manifest_sha256':args.manifest_sha256,'protection_Root_close_sha256':R.CLOSE_SHA,'current19_mode':config['current19_mode']}
    write_new(out/'intent.json',raw_json(outcome));code=None

    try:
        guard.install(); guard.close_inputs(); guard.observe_original_locks()
        lifetime = importlib.import_module('_b_route_reader_lifetime')
        guard.wrap_transport(lifetime)
        guard.inventory = importlib.import_module('_b_route_inventory')
        owner = importlib.import_module('b_route_adoption')
        require(owner.__file__ == str(SOURCE/'scripts/python/b_route_adoption.py') and isinstance(owner.__loader__,Loader), 'original public SourceOnly CLI owner')
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = owner.main(['--root',str(TARGET),'--stage','review-prepare','--operation-id',OPERATION,'--request',REQUEST])
        write_new(out/'owner-stdout.bin',stdout.getvalue().encode('utf-8'))
        write_new(out/'owner-stderr.bin',stderr.getvalue().encode('utf-8'))
        result = json.loads(stdout.getvalue())
        require(type(code) is int and code == 0 and result['status'] == 'review_prepared'
                and result['operation_id'] == OPERATION and result['model_dispatched'] is False
                and result['semantic_execution_required'] is True and result['machine_preservation'] is None
                and all(result[name] is False for name in ('formal_adoption','readiness','runtime_verified')), 'actual complete public review-prepare result')
        require(guard.transport_calls == 1 and len(guard.children) == 1
                and guard.job_observations['assign_success'] == 1 and guard.job_observations['last_active'] == 0
                and guard.job_observations['close_success'] == 1, 'actual original full reader/Job completed')
        require(guard.public_scope_admitted and guard.target_scope_locks, 'actual original scope denominator and locks')
        lock_rows = guard.completed_lock_rows + list(guard.lock_descriptors.values())
        require({row['path'] for row in lock_rows} == guard.locks
                and all(row['acquire_returned'] and row['unlock_returned'] and row['close_returned'] and not row['errors'] for row in lock_rows), 'all actual original nx and target scope locks acquired/unlocked/closed')
        require(len(guard.git_intents) == len(guard.git_records) > 0 and all(row['actual_original_held_OS_exit'] is not None
                and row['actual_handle_closed'] and row['closing_error'] is None and not row['timeout']
                and row['Popen_audit'] and row['CreateProcess_audit'] for row in guard.git_records), 'all original readonly Git held terminals closed')
        guard.target_complete = True
        guard.close_inputs(); source_close(config)
        after = target_close(config, guard)
        review_pins = {name:hash_file(TARGET/name) for name in REVIEW_FILES}
        require(result['subject_ref'] == REVIEW_HOME+'/subject.json' and result['workspace'] == REVIEW_HOME+'/w'
                and result['execution_capture_ref'] == REVIEW_HOME+'/execution.json'
                and result['required_environment'] == {'NEWROGUE_CODEX_REASONING_EFFORT':'high'}, 'actual exact original review outputs and command description')
        write_new(out/'owner-result.json',raw_json(result))
        write_new(out/'lock-events.json',raw_json({'path_events':guard.lock_events,'actual_byte_lock_and_close':lock_rows}))
        write_new(out/'codec-fd-events.json',raw_json(guard.codec_fd_events))
        outcome.update(passed=True,original_owner_returncode=code,owner_result=result,review_files=review_pins,
            actual_native_capture_sha256=hash_file(out/'actual-native-capture.json'),Job_observations=guard.job_observations,
            actual_held_Git=guard.git_records,all_scope_lock_rows=lock_rows,target_after=after,source_closed=True,
            request_ref=REQUEST,request_sha256=config['request_sha256'],stage_receipt_ref=config['stage_receipt_ref'],
            stage_receipt_sha256=config['stage_receipt_sha256'],actual_counts=config['actual_counts'])
        write_new(out/'result.json',raw_json(outcome))
        guard.close_inputs(); source_close(config)
        require(snapshot_tree(TARGET) == after,'post-result original target/member closure')
        print(json.dumps({'passed':True,'stage':'review-prepare','result_sha256':hash_file(out/'result.json'),
                          'model_calls':0,'formal_acceptance':False}),flush=True)
        return 0
    except BaseException as error:
        for name,value in (('owner-stdout.bin',stdout.getvalue()),('owner-stderr.bin',stderr.getvalue())):
            if not (out/name).exists():write_new(out/name,value.encode('utf-8'))
        outcome.update(passed=False,error_type=type(error).__name__,reason=str(error)[:2048],original_owner_returncode=code,
            blocked_actions=guard.blocked,Git_records=guard.git_records,reader_calls=guard.transport_calls,
            Job_observations=guard.job_observations,original_lock_rows=guard.completed_lock_rows+list(guard.lock_descriptors.values()))
        write_new(out/'STOP.json',raw_json(outcome));traceback.print_exc();return 1


if __name__=='__main__':raise SystemExit(main())
