"""Small reviewed control adapter; actual frozen guard, no project import here."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import types

TASK=Path(__file__).absolute().parents[2]
HOME=Path(__file__).absolute().parent
LIB=TASK/'night-handoff/story27-r52-public-review-prepare-host-followup02'
LIB_SHA='628a3dd21d954dcfb4c272b9cac381c4653f38e71b899cccca6395e857adb13c'
REQ=TASK/'night-handoff/story27-r52-atomic-request02-thin-controls-01'
REQ_SHA='a95a79461985dd085ce7aea41ddfb486eae5c03d0a49110143eab6945d9c3324'
NATIVE='logs/ci/2026-11-09/story27-r52-v15-native-profile-seal-native02/config.json'
NATIVE_SHA='c6b38b37aeb69f5b6e5947ce35c0f0f8a33cfcb23369ccd09f67ba8436de2f6e'
REQUEST='logs/ci/2026-11-09/b-route-requests/native-v15-origin02-request-02/request.json'
READY='logs/ci/2026-11-09/story27-r52-atomic-request02-build-01/result.json'
READY_SHA='83b14b25889ca12800e20be0fbc0eb4f1abab7329ad536466ce405c97fe4e1dd'
REQUEST_SHA='30b0c44c35000f5814f879266592c4d0bd3139b830dd3d782ad54448d4993413'
STAGED='logs/ci/2026-11-09/story27-r52-atomic-request02-stage-01/result.json'
STAGED_SHA='ab13385995e2d70a021435c53f51a7a9c80bb158c7367e28dc6b6bc123699b10'
REQUEST_CONFIG='logs/ci/2026-11-09/story27-r52-atomic-request02-seal-01/config.json'
REQUEST_CONFIG_SHA='087907d78eada2f75d064cd8c54845ab84756ca53456dd3b53f4250ba49453d7'
SEAL=TASK/'logs/ci/2026-11-09/story27-r52-atomic-review-prepare-seal-01'
OUT=TASK/'logs/ci/2026-11-09/story27-r52-atomic-review-prepare-01'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,why):
    if not ok:raise RuntimeError('current_review_prepare:'+why)

def members(base,pin):
    raw=(base/'manifest.json').read_bytes();need(sha(raw)==pin,'fixed reviewed manifest')
    value=json.loads(raw)
    for name,row in value['files'].items():
        need('/' not in name and '\\' not in name and sha((base/name).read_bytes())==row['sha256'],'fixed control raw')
    return value

def module(name,path):
    value=types.ModuleType(name);value.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec',dont_inherit=True,optimize=0),value.__dict__)
    return value

def load(manifest_sha):
    own=members(HOME,manifest_sha);members(LIB,LIB_SHA);members(REQ,REQ_SHA)
    R=module('_Root_current_request_metadata',REQ/'control_common.py')
    _,C,P,_=R.load(REQ_SHA)
    H=module('_Root_original_review_prepare_guard',LIB/'review_prepare_host.draft.py')
    need(H.HOME==LIB and H.SOURCE==TASK/'r52' and H.TARGET==P.TARGET,'real library and source identities')
    # Data constant only; original product modules/filenames/operation stay real.
    H.REQUEST=REQUEST
    need(H.hash_file(TASK/NATIVE)==NATIVE_SHA,'original reader/dependency metadata seed')
    return H,R,C,P,own

def close_sources(H,R,C,P,config):
    R.close_sources(H,C,P,config)
    need(config['request_ref']==REQUEST and config['operation_id']==H.OPERATION
         and config['model_calls_allowed']==0,'exact new public request only')

def fresh_native(H,config):
    for name,row in config['dependency_files'].items():need(H.hash_file(name)==row['sha256'],'original80 raw')
    for name,row in config['program_file_identities'].items():need(H.file_identity(name)==row,'actual program identity')
    for name,row in config['source_full_members'].items():need(H.members(H.SOURCE/name)==row,'current complete source members')
    for name,row in config['dependency_members'].items():need(H.members(name,validate_children=False)==row,'original dependency names')

def guard_inputs(H,R,C,guard,config,own,config_path,config_sha):
    guard.files.update({H.key(TASK/ref):pin for ref,pin in {**config['parent_pins'],**config['prerequisite_pins']}.items()})
    guard.files.update({H.key(name):pin for name,pin in config['source_git_metadata'].items()})
    guard.files[H.key(config_path)]=config_sha
    for base,pin in ((HOME,config['control_manifest_sha256']),(LIB,LIB_SHA),(REQ,REQ_SHA),
                     (R.BASE,R.BASE_MANIFEST),(R.THIN,R.THIN_MANIFEST),(C.BASE_HOME,'2278cbe0fb84ef5e4689124852e04908aab9f942e88b0ed768bc4e718e0c67ce')):
        guard.files[H.key(base/'manifest.json')]=pin
        data=own if base==HOME else json.loads(H.read(base/'manifest.json'))
        guard.files.update({H.key(base/name):row['sha256'] for name,row in data['files'].items()})

def safe_environment(H,out):
    inherited=H.os.environ.get('SC_CAPABILITY_MAX_INPUT_TOKENS')
    need(inherited in (None,'70000','96000'),'same finite native04 input limit')
    env={name:H.os.environ[name] for name in ('SystemRoot','WINDIR','SystemDrive','TEMP','TMP','PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS') if name in H.os.environ}
    env.update(CODEX_HOME=str(out/'offline-codex-home'),NEWROGUE_CODEX_REASONING_EFFORT='high',
        TEMP=str(out/'tmp'),TMP=str(out/'tmp'),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',TIKTOKEN_CACHE_DIR=str(TASK/'story22-tokenizer-cache'),
        PATH=str(H.GIT.parent)+H.os.pathsep+str(H.PYTHON.parent),PATHEXT='.EXE',
        GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_SYSTEM=H.os.devnull,GIT_CONFIG_GLOBAL=H.os.devnull,
        GIT_CONFIG_COUNT='0',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
    cli_path=LIB/'cli_binding.draft.py'
    need(H.hash_file(cli_path)=='13e51ca6a806505b68b8bc73b216530809f09d438c6d94b9ada30f7ae7fc6fbd','original CLI DATA helper')
    cli=module('_Root_original_review_CLI_environment',cli_path)
    env=cli.bind_environment(env)
    if inherited is not None:env['SC_CAPABILITY_MAX_INPUT_TOKENS']=inherited
    return env
